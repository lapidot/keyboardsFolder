/*
Copyright 2017 Jack Humbert <jack.humb@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* key matrix size */
#define MATRIX_ROWS 4
#define MATRIX_COLS 10

//F6, F7, B3, B2, B6, B4, F4, D7, D4, D0
//D3, D2, D1, B5
//speaker and oled wiring (wooden Absolem):
#define MATRIX_ROW_PINS { D3, D2, D1, B5}//, E6 }
//#define MATRIX_COL_PINS { F5, F6, F7, B3, B2, B6, B4, F4, D7, C6, D4, D0}
#define MATRIX_COL_PINS { F6, F7, B3, B2, B6, B4, F4, D7, D4, D0}
#define TAPPING_TOGGLE 3

/* combos */
#define COMBO_COUNT 2
#define TAPPING_TERM 200
#define COMBO_TERM 200
#define IGNORE_MOD_TAP_INTERRUPT

#ifndef atreus_CONFIG_H
#define atreus_CONFIG_H

#include "config_common.h"

#define DEVICE_VER      0x0002

#endif
