# Priyadi's Planck Layout

Features:

- Supports QWERTY, Colemak and Workman layouts.
- Cursor and nav cluster on home row.
- Hybrid number row and numpad, located on home row.
- Number layer supports hexadecimal input.
- Left and right side modifiers.
- Emoji layer. An entire layer filled with common emojis.
- Faux-clickey (poor man's replacement for Cherry blue switches)