![rgb](https://i.imgur.com/97E6aSo.jpg)
![wiring](https://i.imgur.com/yL2ybk6.jpg)