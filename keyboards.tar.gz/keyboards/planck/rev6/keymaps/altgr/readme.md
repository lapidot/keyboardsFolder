# The sdothum extended Default Planck Layout

- Colemak-DH layout layer with shift/tab key overlays
- Number and symbol/function key layer
- Hexadecimal keypad layer
- Navigation keypad layer
- Dynamic macro layer
- Autocompletion tap key pairs (),[],{}
- Normalized enter and esc key position across keyboard layers
- Extensive use of tap keys
