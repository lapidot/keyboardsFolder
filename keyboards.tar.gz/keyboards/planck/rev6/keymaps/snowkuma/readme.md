# Snowkuma's Planck Layout  v.0.1

Wide colemak planck layout.  Heavily influenced by the ideas of sdothum and his blog.

Aims to minimize key usage to minimal set and have hands in a comfortable position.

![Colemak](https://i.imgur.com/4B3HdCE.png)
![Symbol](https://i.imgur.com/WYxIJqv.png)
![Regex](https://i.imgur.com/PxTCT6P.png)
![Number](https://i.imgur.com/NzhW26R.png)
![Arrange](https://i.imgur.com/BlTJjyW.png)
![Shortcuts](https://i.imgur.com/p2ooSrC.png)
![Function](https://i.imgur.com/U1F5J3R.png)
![Mouse](https://i.imgur.com/nCHabXV.png)
