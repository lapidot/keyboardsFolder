// Email address
#define MY_EMAIL "myname@email.com"
// Canned responses
#define CANNED_1 "A canned response / template for emails."
