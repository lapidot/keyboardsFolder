# Graham's Planck

## Sounds
I've added a [8ohm 0.5W speaker](http://a.co/6MIKZSy), its a bit large, but it fits in approximately the same space as the ProMicro. I soldered to the pcb hole labeled PC6 on my Rev 3 Planck PCB, and GND on the near by chip. [Pic of an identical mod][https://i1.sndcdn.com/artworks-000128070066-myh0ls-t500x500.jpg] (not mine).
