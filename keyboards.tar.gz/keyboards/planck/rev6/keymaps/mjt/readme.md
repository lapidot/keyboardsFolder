# Mike's Plancklike Planck

- Music/Audio
- Dynamic Macros
- Media Keys
- Works with iPhone Camera Adapter

## Layers

Qwerty for letters and mods.

Raise and Lower are mostly default with a few tweaks.

Adjust layer is tough to get to so it is only for keyboard configuration stuff.

## Dynamic Macros

Hold TAB key, then press ";" to record macro 1 and "'" to record macro 2.

When you are done recording, press TAB again.

For playback of macros, TAB+"," plays macro 1 and TAB+","plays macro 2.
