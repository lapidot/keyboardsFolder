# KMontag42's Planck Layout

[![Built with Spacemacs](https://cdn.rawgit.com/syl20bnr/spacemacs/442d025779da2f62fc86c2082703697714db6514/assets/spacemacs-badge.svg)](http://spacemacs.org)

## Additional Notes
This layout is  WIP as I continute to tinker with my Planck, expect more updates here soon.

## Notable features
* Split spacebar used leader key
* Space cadet style parens
