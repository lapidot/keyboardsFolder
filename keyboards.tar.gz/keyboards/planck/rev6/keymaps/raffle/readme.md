# Raffle's Planck Layout

- Caps -> LCtrl
- LCtrol -> Nav Layer
  + Nav uses pok3r-like nav (IJKL, H/N for home/end, U/P for pgup/pgdn)
- RArrow -> Dev layer
  + handy macros for R programming
  
Also removes keymaps I don't use (dvorak, etc).


