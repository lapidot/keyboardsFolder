# Planck layout for Swedish programmer
I.e. easy access to special keys and åäö.

![layout](https://i.imgur.com/74wHmDh.png)

[KBLE link](http://www.keyboard-layout-editor.com/#/gists/dc01cc2225899308a05ba3ef0031548b)
