# Planck Layout created by [Smittey](https://github.com/smittey) 

A layout with a focus around coding, utilising the home row for symbols. There is an additional FN layer and Space function layer

Main - Qwerty with ctrl swapped around and enter changed to be shift on hold
Lower - Numbers and calculations
Raise - Symbols
Adjust - Keyboard settings and layout changers
FN - Function keys
Space FN - Navigation and media

## Main
![Main layer layout](https://i.imgur.com/jRbqGUN.png)

## Lower
![Lower layer layout](https://i.imgur.com/YmdM1q5.png)
  
## Raise
![Raise layer layout](https://i.imgur.com/BXxOK1S.png)

## Adjust
![Adjust layer layout](https://i.imgur.com/M6qBaXO.png)

## FN
![FN layer layout](https://i.imgur.com/1eiUOH1.png)

## Space Function
![Space function layer layout](https://i.imgur.com/RJMFEdy.png)