# jcorrado Planck keymap

A keymap for the Planck modeled after the way I remap my Kinesis
Advantage keyboards.

The layout is designed to minimize awkward contortions: all modifier and
layer-activation combinations can be performed with either hand's thumb
and pinky.  This leaves the other hand free to complete commands
comfortably.
