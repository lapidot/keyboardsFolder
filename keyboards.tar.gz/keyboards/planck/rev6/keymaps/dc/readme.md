# Practical keymap for Planck Ortholinear 40% Mechanical Keyboard
A custom Dvorak keymap with layers for numbers, symbols, and media keys.