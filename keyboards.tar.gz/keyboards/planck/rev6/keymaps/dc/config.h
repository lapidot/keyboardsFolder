#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#include "../../config.h"

#define TAPPING_TERM 200
#define TAPPING_TOGGLE 3

#endif