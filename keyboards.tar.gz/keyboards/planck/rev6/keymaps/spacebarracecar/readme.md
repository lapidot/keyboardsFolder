# SpacebarRacecar US-International Planck Keymap for German PCs

This keymap emulates most keys of the US-International layout on PCs that have German set as input language.  
This allows the use of the keyboard on any PC in Germany without the need to change any settings.
The keymap is mostly based on the Planck default layout but adds essential features for german input, like access to Ä, Ö, Ü, ß.
