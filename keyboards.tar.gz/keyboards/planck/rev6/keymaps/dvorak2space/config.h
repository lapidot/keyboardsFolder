#pragma once
#define TAPPING_TOGGLE 1
#define PERMISSIVE_HOLD
