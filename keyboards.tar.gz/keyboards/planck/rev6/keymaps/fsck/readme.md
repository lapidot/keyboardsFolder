![preonic:fsck Layout Image](https://i.imgur.com/GOLyPGP.png)

# fsck's Planck Layout

This is largely based on the default planck layout.