# A modified planck layout with arrow cluster

