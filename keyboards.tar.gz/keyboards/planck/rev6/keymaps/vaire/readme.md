#The vaire planck layout

- easy access numpad
- mouse and wheel controls
- flipped keyboard for one hand typing
- sound on all num, scroll, and caps lock