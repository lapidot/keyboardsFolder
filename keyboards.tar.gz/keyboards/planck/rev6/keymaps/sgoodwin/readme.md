# sgoodwin's Planck Layout

Includes:

1. No Dvorak or Plover
2. No alt-swapping
3. Right enter is shift when held down, enter when tapped.
4. Bottom left corner in normal layers is Hyper and not brightness control.
5. Brightness is instead in the bottom corner on raise/lower.

