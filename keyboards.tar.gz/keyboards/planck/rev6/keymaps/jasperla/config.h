#pragma once

#ifdef AUDIO_ENABLE
    #define STARTUP_SONG SONG(PLANCK_SOUND)
#endif

/*
 * MIDI options
 */
#define MIDI_BASIC
