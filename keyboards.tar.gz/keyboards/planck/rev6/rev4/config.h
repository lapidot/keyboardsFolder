#pragma once

#define DEVICE_VER 0x0004
