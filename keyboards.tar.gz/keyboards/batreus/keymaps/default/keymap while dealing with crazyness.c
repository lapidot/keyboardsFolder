	#include QMK_KEYBOARD_H

	// Each layer gets a name for readability, which is then used in the keymap matrix below.
	// The underscores don't mean anything - you can have a layer called STUFF or any other name.
	// Layer names don't all need to be of the same length, obviously, and you can also skip them
	// entirely and just use numbers.
	#include "danl4_common_functions.c"


	// Fillers to make layering more clear
AAASSD.SSS.SSSssssssssSsssssDFsDFFFDSSFDSFFFZZZFFASDF
	const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
	[_WINBASE] = LAYOUT(
	  TT(_XARROWS),	KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		    		KC_Y,		KC_U,		KC_I,		KC_O,		KC_P,		XXXXX,	\
	  OSL(_MIRROR),SHFT_A, CTRL_S,  ALT_D,  GUI_F,	KC_G,					KC_H,		GUI_J,   	ALT_K,    	CTRL_L,  	SHSQ,		XXXXX,	\
	  OSL(_XNUMPAD),Z_UNDO,	X_REDO,	KC_C,	KC_V,	KC_B,					KC_N,		KC_M,		KC_COMM,	SHFT_DOT,	SLASHES,	XXXXX,	\
	  XXXXX,	XXXXX,	SHFT_BS,NUM_TAB,CTRL_SPC,WIN_ENT, 	ALT_BS,,ARROWS,	NUM_ENT,	XXXXX,		XXXXX
	  ),
	  
	  [_MIRROR] = LAYOUT(
	  KC_BSLASH,KC_P,	KC_O,	KC_I,		KC_U,	KC_Y,			KC_MS_ACCEL0,	KC_MS_BTN1,		KC_MS_UP,	KC_MS_BTN2,		KC_Q,	XXXXX,	\
	  _______,	SCLN,	KC_L,	KC_K,		KC_J,	KC_H,			KC_MS_ACCEL1,	KC_MS_LEFT,		KC_MS_DOWN,	KC_MS_RIGHT,	KC_A,	XXXXX,	\
	  _______,	SLASHES,KC_DOT,	KC_COMM,	KC_M,	KC_N,			KC_MS_ACCEL2,	KC_V,			KC_MS_DOWN,	KC_X,			KC_Z,	XXXXX,	\
	  XXXXX,	XXXXX,_______,_______,	_______,_______,		LGUI(KC_DEL),	KC_BSPC,		KC_TAB,	TO(_WINBASE),		XXXXX,	XXXXX	\
	  ),

	  [_ARROWS] = LAYOUT(
	  _______,	KC_LALT,	LSFT(KC_LBRACKET),	KC_LBRACKET,	KC_LPRN,	KC_ESC,	            KC_DEL,		KC_HOME,	KC_UP,		KC_PGUP,	XXXXX,XXXXX,	\
	  _______,	KC_LSHIFT,	KC_LCTRL,			KC_LALT,		KC_RPRN,	XXXXX,	           	KC_PSCR,	KC_LEFT,	KC_DOWN,	KC_RIGHT,	KC_EQUAL,	XXXXX,	\
	  _______,LCTL(KC_Z),	LCTL(KC_X),			LCTL(KC_C),		LCTL(KC_V),	XXXXX,	     		XXXXX,		KC_END,		KC_DOWN,	KC_PGDN,	XXXXX,	XXXXX,	\
	  XXXXX,  XXXXX,	_______,			_______,		_______,_______,	        	_______,	_______,	_______,	_______,	XXXXX,	XXXXX	\
	  ),

	  [_XARROWS] = LAYOUT(
	   _______,	KC_LCTRL,        KC_HOME,	KC_UP,	 	KC_PGUP,	XXXXX,			XXXXX,		KC_HOME,	KC_UP,	  	KC_PGUP,	XXXXX,	XXXXX,	\
	  _______,	KC_LSHIFT,       KC_LEFT,	KC_DOWN,	KC_RIGHT,	KC_EQUAL,		KC_PSCR,	KC_LEFT,	KC_DOWN,	KC_RIGHT,	KC_EQUAL,	XXXXX,	\
	  _______,	LCTL(KC_LSHIFT), KC_END,	KC_DOWN,	KC_PGDN,	XXXXX,			XXXXX,		KC_END,	  	KC_DOWN,	KC_PGDN,	XXXXX,	XXXXX,	\
	  XXXXX,  XXXXX,         _______,	_______,	LSFT_T(KC_DEL),_______,		_______,	_______,	_______,	_______,	XXXXX,	XXXXX	\
	 ),

	  [_NUMPAD] = LAYOUT(
	  _______,  KC_VOLU,  WBASE,  KC_PIPE, KC_TILD,   KC_ESC,    		KC_ASTR,  KC_7,     KC_8,   KC_9,      KC_0,  XXXXX,  \
	  _______,  KC_VOLD,  CURLY,  SQUAR,   PARAN,     KC_APP,    		KC_SLSH,  KC_4,     KC_5,   KC_6,      KC_PLUS, XXXXX,  \
	  _______,  KC_MUTE,  KC_CUT, KC_COPY, KC_PASTE,  KC_PSCR,   		KC_0,     KC_1,     KC_2,   KC_3,      KC_MINS, XXXXX,  \
	  XXXXX,  XXXXX,   WBASE,  _______, _______,_______,   	KC_DEL,  _______,  _______,KC_KP_DOT, XXXXX, XXXXX\
	   ),

	  [_XNUMPAD] = LAYOUT(
	  _______,  KC_ASTR,  KC_7,  KC_8,   KC_9, KC_0,        KC_ASTR,  KC_7,     KC_8,   KC_9,      KC_0,  XXXXX,  \
	  _______,  KC_SLSH,  KC_4,  KC_5,   KC_6, KC_PLUS,     KC_SLSH,  KC_4,     KC_5,   KC_6,      KC_PLUS, XXXXX,  \
	  _______,  KC_0,     KC_1,  KC_2,   KC_3, KC_MINS,     KC_0,     KC_1,     KC_2,   KC_3,      KC_MINS, XXXXX,  \
	  XXXXX,XXXXX, _______,_______,_______,_______,    _______,  _______,  _______,KC_KP_DOT, XXXXX, XXXXX  \
	  ),

	/* Adjust (Lower + Raise)
	 * |------+------+------+------+------+------.             ,------+------+------+------+------+------|
	 * |      | Reset|      |      |      |      |             |      |      |      |      |      |  Del |
	 * |------+------+------+------+------+------|             |------+------+------+------+------+------|
	 * |      |      |      |Audoff|Aud on|AGnorm|             |AGswap|Qwerty|Colemk|Dvorak|      |      |
	 * |------+------+------+------+------+------|             |------+------+------+------+------+------|
	 * |      |Voice-|Voice+|Musoff|Mus on|      |             |      |      |      |      |      |      |
	 * |------+------+------+------+------+------+------+------+------+------+------+------+------+------|
	 * |      |      |      |      |      |      |      |      |      |      |      |      |      |      |
	 * `-------------------------------------------------------------------------------------------------'
	 */
	  [_SYMBOL] = LAYOUT(
	  XXXXX,	KC_TILD,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,		KC_CIRC,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,	XXXXX,	\
	  XXXXX,	WBASE,		KC_DLR,		KC_PERC,	KC_CIRC,	KC_TILD,		KC_TILD,	KC_DLR,		KC_PERC,	KC_CIRC,	WBASE,		XXXXX,	\
	  XXXXX,	XXXXX,		KC_EXLM,	KC_AT,		KC_HASH,	XXXXX,			KC_EQUAL,	KC_EXLM,	KC_AT,		KC_HASH,	KC_QUES,	XXXXX,	\
	  XXXXX,	XXXXX,	_______,	_______,	_______,	_______,		_______,	_______,	_______,	_______,	XXXXX,	XXXXX\
	 ),


	[_FUNC] = LAYOUT(  /* ADJUST - Macros,	Layer Switching,	Function Keys */
	  _______,KC_VOLU,	WBASE,	   RESET,   XXXXX,		KC_APP,		  XXXXX,	KC_F7,	KC_F8,	 KC_F9,	  KC_F10,	XXXXX,	\
	  WBASE,  KC_LSHIFT,KC_LCTRL,  KC_LALT,	KC_LGUI,	LCTL(KC_LALT),KC_EQUAL,	KC_F4,	KC_F5,	 KC_F6,	  KC_F11,	XXXXX,	\
	  XXXXX,  KC_CAPS,	KC_INSERT, XXXXX,	KC_F,	    KC_PSCR,	  XXXXX,	KC_F1,	KC_F2,	 KC_F3,	  KC_F12,	XXXXX,	\
	  XXXXX,  XXXXX,	_______,   _______,	_______,	_______,	  _______,	_______,_______, _______,	XXXXX,XXXXX\
	)
/*,
	[_LEFTHAND] = LAYOUT(  // ADJUST - Macros,	Layer Switching,	Function Keys  
	 TT(_XARROWS),	KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		    KC_Y,		KC_U,		KC_I,		KC_O,		KC_P,		KC_BSLASH,	\
	  OSL(_MIRROR),SHFT_A, CTRL_S,  ALT_D,  GUI_F,	KC_G,			KC_H,		GUI_J,   	ALT_K,    	CTRL_L,  	SHSQ,		_______,	\
	  OSL(_XNUMPAD),Z_UNDO,	X_REDO,	KC_C,	KC_V,	KC_B,			KC_N,		KC_M,		KC_COMM,	SHFT_DOT,	SLASHES,	KC_RSHIFT,	\
	  OSL(_SYMBOL),	ARROWS,	MIRR_DEL,	NUMPAD,	LSFT_T(KC_BSPC),	CTRL_TAB,CTL_T(KC_ENT),	GUI_T(KC_SPC),ARROWS,	SYBL_ESC,	KC_EQUAL,		CPYPST
	)*/


	};
