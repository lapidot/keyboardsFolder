# Balbuzard Pro Layout

My keymap for the Balbuzard (choc-spaced), based on the Hands Down Alt-tx layout.
