#include QMK_KEYBOARD_H
//#define PREONIC_YES                 // LEFT HANDED SPLIT (MINI MANUFORM 4X5)
#include "danl4_common_functions.c"

//make handwired/dactyl_manuform/mini4x5:danl4
//dan@Lithium:~/Documents/QMK/qmk_firmware$
//make handwired/dactyl_manuform/mini4x5:danl4:avrdude



const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
[_WINBASE] = LAYOUT(  /* Base Layer */
 /*
  * CLEARMODS
  KC_Q,   KC_W,    KC_E,   KC_R,    KC_T,				KC_Y,	KC_U,    KC_I,     KC_O,     KC_P,\
  SHFT_A, CTRL_S,  ALT_D,  GUI_F,   KC_G,				KC_H,	GUI_J,   ALT_K,    CTRL_L,   SHSQ,\
  KC_Z,	  KC_X,    KC_C,   KC_V,    KC_B,				KC_N,	KC_M,    CTRL_COMM,SHFT_DOT, SLASHES,\
  OSL_SYM,TGMOUSE, NUM_TAB,CTRL_SPC,WIN_ENT, 	ALT_BS,SHFT_SPC,ARROWS,   FN_ESC,   KC_EQUAL,\
						MIRROR,SHFT_BS,	WIN_ENT,   NUMPAD\
  KC_ESC,   KC_EXLM, KC_AT,   KC_HASH, KC_DLR,  KC_PERC, KC_CIRC, KC_AMPR, KC_ASTR, KC_LPRN, KC_RPRN, KC_BSPC, \
  KC_TAB,   KC_Q,    KC_W,    KC_F,    KC_P,    KC_G,    KC_J,    KC_L,    KC_U,    KC_Y,    KC_QUOT, KC_ENT,  \
  KC_BSPC,  KC_A,    KC_R,    KC_S,    KC_T,    KC_D,    KC_H,    KC_N,    KC_E,    KC_I,    KC_O,    KC_ENT,  \
  SHFT_CAP, KC_Z,    KC_X,    KC_C,    LC_V,    KC_B,    KC_K,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, KC_RSFT, \
  CTRLB,    TD(SUP), KC_LALT, KC_LCTL, TD(LOW), KC_SPC,      TD(RAI), KC_LEFT, KC_DOWN, KC_UP,   KC_RGHT  \
),*/
  KC_Q,   KC_W,    KC_E,   KC_R,    KC_T,				KC_Y,	KC_U,    KC_I,     KC_O,     KC_P,\
  SHFT_A, CTRL_S,  ALT_D,  GUI_F,   KC_G,				KC_H,	GUI_J,   ALT_K,    CTRL_L,   SHSQ,\
  KC_Z,	  KC_X,    KC_C,   KC_V,    KC_B,				KC_N,	KC_M,    KC_COMM,KC_DOT, SLASHES,\
  OSL_XNUM,TGMOUSE, NUM_TAB,CTRL_SPC,WIN_ENT, 	ALT_BS,SHFT_SPC,ARROWS,   CLEARMODS,   KC_EQUAL,\
						MIRROR,SHFT_BS,			WIN_ENT,   NUMPAD\
),////OSL_SYM,TGMOUSE, KC_LSFT,	CTRL_BS,ARR_TAB, ARROWS,   FN_ESC,   KC_EQUAL,
//Z_UNDO, X_REDO,
/*BATREUS: 
KC_TAB,  KC_ESC,
                   NUMPAD, KC_BSPC,CTLDEL,//regular thumbs left
                                           KC_LGUI,  MO(_MIRROR),//middle thumbs for BATreus
                                                              KC_ENT,KC_SPC,  ARROWS, //regular thumbs right
                       		                                                                         KC_MINUS,       KC_EQUAL,
Atreus:
KC_TAB,  KC_ESC,KC_LGUI,NUMPAD, KC_BSPC, CTLDEL,         SFT_ENT, KC_SPC,  ARROWS,   KC_MINUS, KC_EQUAL, CPYPST, 
*/   

[_MIRROR] = LAYOUT(  /*MIRROR and mouse*/
  KC_P,		KC_O,	KC_I,	KC_U,   KC_Y,			KC_MS_ACCEL0, 	KC_MS_BTN1,	KC_MS_UP,  KC_MS_BTN2, 	KC_MS_WH_UP, \
  SHSQ,		CTRL_L,	ALT_K,	GUI_J,  KC_H,			KC_MS_ACCEL1, 	KC_MS_LEFT,	KC_MS_DOWN,KC_MS_RIGHT,	KC_MS_WH_DOWN, \
  SLASHES,	KC_DOT,	KC_COMM,KC_M,	KC_N,			KC_MS_ACCEL2, 	XXXXX,		KC_MS_BTN3,XXXXX,		XXXXX, \
  CLEARMODS,TD(QUO),_____,	KC_DEL, KC_LSHIFT,		LGUI_T(KC_DEL), _____,		_____,		CLEARMODS,	_____, \
							_____,_____,			_____,_____ \
  ),
/*BATREUS:
KC_EQUAL, KC_MINUS,       _____,   KC_SPC,   RSFT_T(KC_ENT),   KC_LCTL, KC_LGUI, KC_DEL, KC_BSPC, _____, KC_LGUI,KC_LALT, \

// ATREUS:
CPYPST, KC_EQUAL, KC_MINUS,       _____,   KC_SPC, RSFT_T(KC_ENT),LGUI(KC_DEL),KC_BSPC,_____,KC_LGUI,KC_LALT,NUMPAD, \
  */


/*
[_XARROWS] = LAYOUT(  // RAISE - Arrows for both hands 
  KC_VOLU,  KC_HOME,   KC_UP,   KC_PGUP,	CURLY, XXXXX,  KC_HOME, KC_UP,   KC_PGUP,  XXXXX,\
  KC_LSFT,  CTRL_LEFT, KC_LEFT, KC_RIGHT,	PARAN, KC_PSCR,  KC_LEFT, KC_DOWN, KC_RIGHT, XXXXX,\
  KC_VOLD,	KC_END,    KC_DOWN, KC_PGDN,	SQUAR, XXXXX,  KC_END,  KC_DOWN, KC_PGDN,  XXXXX, \
  CLEARMODS,	_____,   	_____,   	_____,	_____, _____,  _____, _____, _____,  _____, \
								  _____, 	_____,   	_____,   	_____\
),
*/
/*
BATreus
  _____, _____, FUNCTN, _____, _____, _____, _____,  _____, _____, FUNCTN,  _____, _____, \

Atreus
  _____, _____, _____, _____, _____, _____, _____,  _____,  FUNCTN,_____,  _____, _____, \

*/



[_ARROWS] = LAYOUT(  /* RAISE - Arrows for right hand*/
	KC_LALT,	LSFT(KC_LBRACKET),	KC_LBRACKET,KC_LPRN,	KC_RPRN,	        XXXXX,	KC_HOME,KC_UP,	KC_PGUP,	XXXXX,\
	KC_LSHIFT,	KC_LCTRL,			KC_LALT,	KC_LGUI,	KC_APP,	           	KC_PSCR,KC_LEFT,KC_DOWN,KC_RIGHT,	KC_EQUAL,	\
	LCTL(KC_Z),	LCTL(KC_X),			LCTL(KC_C),	LCTL(KC_V),	KC_PSCR,	     	XXXXX,	KC_END,	KC_DOWN,KC_PGDN,	XXXXX,	\
	CLEARMODS,	_____,   			_____,   	_____,		_____, 				_____,  _____,	_____,	_____,		_____, \
												_____,		_____,   			_____,	_____\
),

[_NUMPAD] = LAYOUT(  /* LOWER - Numpad for right hand, parenthesis and volumne (and cut copy paste) for left*/
	KC_VOLU,  WBASE,	KC_PIPE, 	KC_TILD,	KC_ESC,    		KC_ASTR,KC_7,	KC_8,   KC_9,      KC_0, \
	KC_VOLD,  CURLY,	SQUAR,   	PARAN,		KC_APP,    		KC_SLSH,KC_4,	KC_5,   KC_6,      KC_PLUS, \
	KC_MUTE,  KC_CUT,	KC_COPY, 	KC_PASTE,	KC_PSCR,   		KC_0,	KC_1,	KC_2,   KC_3,      KC_MINS, \
	CLEARMODS,_____,	_____,		_____,		_____,			_____,	_____,_____,KC_DOT, _____, \
	_____,_____, _____, _____\
),	

[_XNUMPAD] = LAYOUT(  /* LOWER - Numpad both hands*/
/*  KC_TILD, KC_EXLM, KC_AT,   KC_HASH, KC_DLR,  KC_PERC, KC_CIRC, KC_AMPR, KC_ASTR, KC_QUES, KC_DQT,  KC_DEL,  \
  KC_TILD, KC_EXLM, KC_AT,   KC_HASH, KC_DLR,  KC_PERC, KC_CIRC, KC_AMPR, KC_ASTR, KC_QUES, KC_DQT,  KC_DEL,  \
  KC_DEL,  KC_LBRC, KC_RBRC, KC_MINS, KC_UNDS, KC_HOME, KC_END,  KC_LPRN, KC_RPRN, KC_SLSH, KC_SCLN, KC_PGUP, \
  CPYPST,  XXXXX, C(KC_X), KC_LABK, KC_RABK, XXXXX, XXXXX, KC_LCBR, KC_RCBR, KC_BSLS, KC_COLN, KC_PGDN, \
  _____, _____, _____, _____, _____,      KC_TAB,      _____, _____, _____, _____, _____  \*/

	KC_ASTR,KC_7,   KC_8,	KC_9,   KC_0,			KC_ASTR,KC_7,   KC_8,	KC_9,   KC_0,    \
	KC_SLSH,KC_4,   KC_5,	KC_6,   KC_PLUS,		KC_SLSH,KC_4,   KC_5,	KC_6,   KC_PLUS, \
	KC_0, 	KC_1,   KC_2,	KC_3,	KC_MINS,		KC_0,	KC_1,   KC_2,	KC_3,	KC_MINS, \
	_____,KC_KP_DOT,_____,_____,_____,		_____,_____,KC_KP_DOT,CLEARMODS, _____, \
	CLEARMODS,RESET, _____, _____\
/*
BATreus
  _____, _____, FUNCTN, _____, _____, _____, _____,  _____, _____, FUNCTN,  _____, _____, \

Atreus
  _____, _____, _____, FUNCTN, _____, _____, _____,  _____ ,_____,_____,  _____, _____, \

*/

),


[_FUNC] = LAYOUT(  /* ADJUST - Function Keys for both hands */
/*  UNIWIN,  XXXXX, XXXXX, RANDIG,  RANDIG,  KC_INS,  XXXXX, XXXXX,  XXXXX, XXXXX, AU_TOG, MU_TOG,  \
  UNILIN,  SUPA2,   XXXXX, XXXXX, XXXXX, XXXXX, XXXXX, KC_F1,    KC_F2,   KC_F3,   KC_F4,  XXXXX, \
  XXXXX, DEGREE,  IBANG,   LAROW,   RAROW,   SWCOLE,  COLEMAK, KC_F5,    KC_F6,   KC_F7,   KC_F8,  BL_INC,  \
  _____, CADKEY,  MICRO,   WOMEGA,  OMEGA,   XXXXX, XXXXX, KC_F9,    KC_F10,  KC_F11,  KC_F12, BL_DEC,  \
  _____, _____, _____, _____, _____,      RESET,       _____,  XXXXX, MUV_DE,  MUV_IN, BL_TOGG  \*/


	XXXXX,	XXXXX,	KC_BRIU, XXXXX,		KC_WFWD, 		XXXXX,KC_F7,  KC_F8,   KC_F9, KC_F10, \
	XXXXX,	KC_MPRV,KC_MPLY, KC_MNXT,	KC_WBAK,		XXXXX,KC_F4,  KC_F5,   KC_F6, KC_F11, \
	XXXXX,	XXXXX,	KC_BRID, XXXXX,		XXXXX,			XXXXX,KC_F1,  KC_F2,   KC_F3, KC_F12, \
	CLEARMODS,KC_CAPS,_____, _____, _____, 		_____,_____,_____, _____,RESET, \
	_____, _____, _____, _____  \
	
),

[_SYMBOL] = LAYOUT(  /* SYMBOLS layer */

	KC_TILD, 	KC_AMPR, KC_ASTR, KC_LPRN, KC_RPRN, 		KC_CIRC, KC_AMPR, KC_ASTR, KC_LPRN, KC_F10,   \
	WBASE,   	KC_DLR,  KC_PERC, KC_CIRC, KC_TILD,		XXXXX, KC_F4,   KC_F5,   KC_F6,   KC_F11, \
	XXXXX, 		KC_EXLM, KC_AT,   KC_HASH, XXXXX,		_____, KC_EXLM, KC_AT,   KC_LCBR, _____, \
	CLEARMODS, _____, _____, _____, _____, 	_____, _____,_____,   _____, _____, \
	_____, _____, _____, _____  \

),

[_MOUSE] = LAYOUT(  /* mouse for left hand, a mess for right hand */

	KC_TILD, KC_MS_BTN1,	KC_MS_UP,  	KC_MS_BTN2,	KC_MS_WH_UP, 	KC_ESC, XXXXX, XXXXX, XXXXX,	XXXXX, \
	WBASE,   KC_MS_LEFT,	KC_MS_DOWN,	KC_MS_RIGHT,KC_MS_WH_DOWN,	XXXXX, KC_LGUI,   KC_LALT, KC_LCTRL,KC_LSHIFT, \
	XXXXX, XXXXX,    KC_MS_BTN3,	XXXXX,	XXXXX,		XXXXX, XXXXX, XXXXX, XXXXX, XXXXX, \
	CLEARMODS, _____, 	_____, 	_____, 	_____, 	_____, _____,_____,   _____, _____, \
	_____, _____, _____, 	_____ \

)
};
