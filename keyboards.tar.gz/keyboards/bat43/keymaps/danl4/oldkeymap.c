/* Copyright 2020 yfuku
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H
#include "danl4_common_functions.c"    
// Defines names for use in layer keycodes and the keymap


//#define L_SPC LT(_LOWER, KC_SPC)
//#define R_ENT LT(_RAISE, KC_ENT)

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
[_WINBASE] = LAYOUT(
	TG(_XARROWS),KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		   	KC_Y,	KC_U,	KC_I,	KC_O,	KC_P,	KC_BSLASH,
	TT(_MIRROR),SHFT_A, CTRL_S,  ALT_D,  GUI_F,	KC_G, KC_SPACE, KC_H,   KC_J,   KC_K,   KC_L,   SHSQ,	TD(QUO),
	OSL(_XNUMPAD),KC_Z,	KC_X,	KC_C,	KC_V,	KC_B,			KC_N,	KC_M,	KC_COMM,KC_DOT,	SLASHES,KC_RSHIFT,
						   NUM_TAB,CTRL_SPC,WIN_ENT, 			ALT_BS,SHFT_SPC,ARROWS,
					OSL(_SYMBOL), TO(_LEFTHAND),     NUM_ENT,    CLEARMODS,    MIRROR
    ),
[_LEFTHAND] = LAYOUT(
	OSM(MOD_LCTL),	KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		   		KC_Y,	KC_U,	KC_I,	KC_O,	KC_P,	KC_BSLASH,
	KC_BSPC,		SHFT_A, CTRL_S,  ALT_D,  GUI_F,	KC_G,	TG(_XARROWS),	KC_H,	GUI_J,	ALT_K, 	CTRL_L,	SHSQ,	TD(QUO),
	OSM(MOD_LSFT),	KC_Z,	KC_X,	KC_C,	KC_V,	KC_B,				KC_N,	KC_M,	KC_COMM,KC_DOT,	SLASHES,KC_RSHIFT,
                      LT(_XNUMPAD,KC_TAB), LT(_MIRROR, KC_SPACE), _______,          KC_DEL,  _______, _______,
                                            _______, WBASE,          _______, _______, WBASE
    ),
 [_MIRROR] = LAYOUT(
 KC_BSLASH,KC_P,	KC_O,	KC_I,	KC_U,	KC_Y,				KC_MS_ACCEL0,	KC_MS_BTN1,		KC_MS_UP,	KC_MS_BTN2,		KC_Q,	KC_BSLASH,
  _______,	TD(SCL),KC_L,	KC_K,	KC_J,	KC_H,	_______,	KC_MS_ACCEL1,	KC_MS_LEFT,		KC_MS_DOWN,	KC_MS_RIGHT,	KC_A,	TD(QUO),
  KC_LSHIFT,SLASHES,KC_DOT,	KC_COMM,KC_M,	KC_N,				KC_MS_ACCEL2,	KC_V,			KC_MS_DOWN,	KC_X,			KC_Z,	KC_RSHIFT,
						  _______, KC_DEL, KC_BSPC,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   ),



 [_ARROWS] = LAYOUT(
  _______,	KC_LALT,	LSFT(KC_LBRACKET),	KC_LBRACKET,KC_LPRN,	KC_ESC,	            KC_DEL,KC_HOME,	KC_UP,	KC_PGUP,	XXXXX,_______,
  WBASE,	KC_LSHIFT,	KC_LCTRL,			KC_LALT,	KC_RPRN,	XXXXX,_______,     	KC_PSCR,KC_LEFT,KC_DOWN,KC_RIGHT,	KC_EQUAL,_______,
  _______,LCTL(KC_Z),	LCTL(KC_X),			LCTL(KC_C),	LCTL(KC_V),	XXXXX,	     		XXXXX,	KC_END,	KC_DOWN,KC_PGDN,	XXXXX,	_______,
						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, TO (_WINBASE)
   ),

   [_XARROWS] = LAYOUT(
  _______,	KC_LCTRL,	KC_HOME,	KC_UP,	 	KC_PGUP,	XXXXX,			XXXXX,		KC_HOME,	KC_UP,	KC_PGUP,	XXXXX,	_______,
  WBASE,	KC_LSHIFT,	KC_LEFT,	KC_DOWN,	KC_RIGHT,	KC_EQUAL,_______,KC_PSCR,	KC_LEFT,	KC_DOWN,KC_RIGHT,	KC_EQUAL,	_______,
  _______,	LCTL(KC_LSHIFT), KC_END,KC_DOWN,	KC_PGDN,	XXXXX,			XXXXX,		KC_END,	  	KC_DOWN,	KC_PGDN,	XXXXX,	_______,
 						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   ),

   [_NUMPAD] = LAYOUT(
  _______,  KC_VOLU,  WBASE,  KC_PIPE, KC_TILD,   KC_ESC,    		KC_ASTR,  KC_7,     KC_8,   KC_9,      KC_0,  _______,
  WBASE,  KC_VOLD,  CURLY,  SQUAR,   PARAN,     KC_APP,_______, KC_SLSH,  KC_4,     KC_5,   KC_6,      KC_PLUS, KC_ASTR,
  _______,  KC_MUTE,  KC_CUT, KC_COPY, KC_PASTE,  KC_PSCR,   		KC_0,     KC_1,     KC_2,   KC_3,      KC_MINS, KC_PLUS,
  						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   ),

   [_XNUMPAD] = LAYOUT(
  _______,  KC_ASTR,  KC_7,  KC_8,   KC_9, KC_0,        KC_ASTR,  KC_7,     KC_8,   KC_9,      KC_0,  _______,
  WBASE,  KC_SLSH,  KC_4,  KC_5,   KC_6, KC_PLUS,_______,KC_SLSH,  KC_4,     KC_5,   KC_6,      KC_PLUS, KC_ASTR,
  _______,  KC_0,     KC_1,  KC_2,   KC_3, KC_MINS,     KC_0,     KC_1,     KC_2,   KC_3,      KC_MINS, KC_PLUS,
  						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   ),

   [_SYMBOL] = LAYOUT(
  XXXXX,KC_TILD,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,		KC_CIRC,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,	_______,
  WBASE,XXXXX,		KC_DLR,		KC_PERC,	KC_CIRC,	KC_TILD,_______,KC_TILD,	KC_DLR,		KC_PERC,	KC_CIRC,	WBASE,		XXXXX,
  XXXXX,XXXXX,		KC_EXLM,	KC_AT,		KC_HASH,	XXXXX,			KC_EQUAL,	KC_EXLM,	KC_AT,		KC_HASH,	KC_QUES,	_______,
 						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   ),

   [_FUNC] = LAYOUT(
	_______,KC_VOLU,	WBASE,	   KC_BRIU, RESET,		KC_APP,		  CLEARMODS,KC_F7,	KC_F8,	 KC_F9,	  KC_F10,	_______,
	WBASE,  KC_LSHIFT,KC_LCTRL,  KC_LALT,	KC_LGUI,	LCTL(KC_LALT),_______,KC_EQUAL,	KC_F4,	KC_F5,	 KC_F6,	  KC_F11,	_______,
	XXXXX,  KC_CAPS,	KC_INSERT, KC_BRID,	KC_F,	    KC_PSCR,	  CLEARMODS,KC_F1,	KC_F2,	 KC_F3,	  KC_F12,	_______,
  						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          _______, _______, WBASE
   )



   
};
