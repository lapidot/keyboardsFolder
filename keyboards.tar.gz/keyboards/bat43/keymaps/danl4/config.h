/*
*/

#define COMBO_COUNT 2
#define TAPPING_TERM 200
