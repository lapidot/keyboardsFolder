#include QMK_KEYBOARD_H
#include "danl4_common_functions.c"    



enum combos {
  QW_BS,
  YI_Ent,//not great for hebrew ון, swap with ER, CV, MComma
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
 [_WINBASE] = LAYOUT(
	TG(_XARROWS),KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		   	 KC_Y,	KC_U,	KC_I,	KC_O,	KC_P,	OSL(_FUNC),
	TT(_MIRROR),SHFT_A, CTRL_S, ALT_D,  GUI_F,	KC_G,	KC_SPACE,KC_H,	GUI_J,   ALT_K,   CTRL_L,   SHSQ,	KC_ENT,
	OSL(_XNUMPAD),MIRR_Z,KC_X,	KC_C,	KC_V,	MIRR_B,			 KC_N,	KC_M,	KC_COMM,KC_DOT,	SLASHES,OSL(_NUMPAD),
						   NUM_TAB,CTRL_SPC,WIN_ENT, 			ALT_BS,SHFT_SPC,ARROWS,
						OSL(_SYMBOL), TO(_LEFTHAND),     		TO(_MIRROR),CLEARMODS, OSL(_SYMBOL)
    ),
 [_LEFTHAND] = LAYOUT(
	OSM(MOD_LCTL),	KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		   		KC_Y,	KC_U,	KC_I,	KC_O,	KC_P,	KC_BSLASH,
	KC_BSPC,		SHFT_A, CTRL_S,  ALT_D,  GUI_F,	KC_G,	TG(_XARROWS),	KC_H,	GUI_J,	ALT_K, 	CTRL_L,	SHSQ,	TD(QUO),
	OSM(MOD_LSFT),	KC_Z,	KC_X,	KC_C,	KC_V,	KC_B,				KC_N,	KC_M,	KC_COMM,KC_DOT,	SLASHES,KC_RSHIFT,
                      LT(_XNUMPAD,KC_TAB), LT(_MIRROR, KC_SPACE), _______,          KC_DEL,  _______, WBASE,
                                            _______, WBASE,          CLEARMODS, WBASE, WBASE
    ),
	
 [_MIRROR] = LAYOUT(
	KC_BSLASH,KC_P,	  KC_O,		KC_I,	KC_U,	KC_Y,		 KC_MS_ACCEL0,	KC_MS_BTN1,	KC_MS_UP,	KC_MS_BTN2,	KC_MS_BTN3,	KC_BSLASH,
	_______,  TD(SCL),KC_L,		KC_K,	KC_J,	KC_H,_______,KC_MS_ACCEL1,	KC_MS_LEFT,	KC_MS_DOWN,	KC_MS_RIGHT,KC_MS_WH_UP,	TD(QUO),
	KC_LSHIFT,SLASHES,KC_DOT,	KC_COMM,KC_M,	KC_N,		 KC_MS_ACCEL2,	KC_MS_WH_LEFT,		KC_MS_DOWN,	KC_MS_WH_RIGHT,		KC_MS_WH_DOWN,	KC_RSHIFT,
						  OSL(_XNUMPAD),RSFT_T(KC_DEL),KC_BSPC,	KC_ENT,			LGUI(KC_DEL),	KC_BSPC,
									_______, _______,          CLEARMODS, WBASE, WBASE
   ),
   
   
 [_ARROWS] = LAYOUT(
  _______,		KC_LALT,	LSFT(KC_LBRACKET),	KC_LBRACKET,KC_LPRN,	KC_ESC,	        KC_DEL,	KC_HOME,KC_UP,	KC_PGUP,	KC_ENTER,_______,
  TO(_WINBASE),	KC_LSHIFT,	KC_LCTRL,			KC_LALT,	KC_LGUI,	KC_APP,_______, KC_PSCR,KC_LEFT,KC_DOWN,KC_RIGHT,	KC_EQUAL,_______,
  _______,		LCTL(KC_Z),LSFT(KC_RBRACKET),KC_RBRACKET,KC_RPRN,	XXXXX,	     		KC_ENT,	KC_END,	KC_DOWN,KC_PGDN,	OSL(_NUMPAD),	_______,
						  _______, _______, _______,          KC_BSPC, _______, _______,
									_______, _______,          CLEARMODS, WBASE, TO(_WINBASE)
   ),
   
 [_XARROWS] = LAYOUT(
  _______,	KC_LCTRL,	KC_HOME,	KC_UP,	KC_PGUP,	XXXXX,			XXXXX,		KC_HOME,	KC_UP,	KC_PGUP,	XXXXX,	_______,
  WBASE,	KC_LSHIFT,	KC_LEFT,	KC_DOWN,KC_RIGHT,	KC_EQUAL,_______,KC_PSCR,	KC_LEFT,	KC_DOWN,KC_RIGHT,	KC_EQUAL,	_______,
  _______,	LCTL(KC_LSHIFT),KC_END,KC_DOWN,	KC_PGDN,	XXXXX,			XXXXX,		KC_END,	  	KC_DOWN,	KC_PGDN,	XXXXX,	_______,
 						  _______, LSFT_T(KC_DEL), _______,          _______, _______, _______,
									_______, _______,          CLEARMODS, WBASE, WBASE
   ),
 
 [_NUMPAD] = LAYOUT(
  _______,  KC_VOLU,  WBASE,  KC_PIPE, KC_TILD,   KC_ESC,    		KC_EQUAL,  KC_7,     KC_8,   KC_9,   KC_0,  _______,
  WBASE,  	KC_VOLD,  CURLY,  SQUAR,   PARAN,     KC_APP,_______, 	KC_KP_DOT,  KC_4,     KC_5,   KC_6,   KC_PLUS, KC_ASTR,
  _______,  KC_MUTE,  LSFT(KC_RBRACKET),KC_RBRACKET, KC_RPRN,  		KC_PSCR,  KC_0,     KC_1,   KC_2,   KC_3,    KC_MINS, KC_PLUS,
  						  _______, _______, _______,          KC_ENT, _______, _______,
									_______, _______,          CLEARMODS, WBASE, WBASE
   ),
 [_XNUMPAD] = LAYOUT(
  _______,KC_EQUAL,  KC_7,  KC_8,   KC_9, KC_0,				KC_EQUAL,  KC_7,     KC_8,   KC_9,      KC_0,  _______,
  WBASE,  KC_KP_DOT,  KC_4,  KC_5,   KC_6, KC_PLUS, _______,	KC_KP_DOT,  KC_4,     KC_5,   KC_6,      KC_PLUS, KC_ASTR,
  _______,KC_0,     KC_1,  KC_2,   KC_3, KC_MINS,			KC_0,     KC_1,     KC_2,   KC_3,      KC_MINS, KC_PLUS,
					  _______, _______, _______,          _______, _______, _______,
								_______, _______,          CLEARMODS, WBASE, WBASE
   ),  
 [_SYMBOL] = LAYOUT(
  XXXXX,KC_TILD,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,		KC_CIRC,	KC_AMPR,	KC_ASTR,	KC_LPRN,	KC_RPRN,	_______,
  WBASE,XXXXX,		KC_DLR,		KC_PERC,	KC_CIRC,	KC_TILD,_______,KC_TILD,	KC_DLR,		KC_PERC,	KC_CIRC,	WBASE,		XXXXX,
  XXXXX,XXXXX,		KC_EXLM,	KC_AT,		KC_HASH,	XXXXX,			KC_EQUAL,	KC_EXLM,	KC_AT,		KC_HASH,	KC_QUES,	_______,
 						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          CLEARMODS, WBASE, WBASE
   ),
   
 [_FUNC] = LAYOUT(
	_______,KC_VOLU,	WBASE,	   KC_BRIU, RESET,		KC_APP,		  CLEARMODS,KC_F7,	KC_F8,	 KC_F9,	  KC_F10,	_______,
	WBASE,  KC_LSHIFT,KC_LCTRL,  KC_LALT,	KC_LGUI,	LCTL(KC_LALT),_______,KC_EQUAL,	KC_F4,	KC_F5,	 KC_F6,	  KC_F11,	_______,
	XXXXX,  KC_CAPS,	KC_INSERT, KC_BRID,	KC_F,	    KC_PSCR,	  CLEARMODS,KC_F1,	KC_F2,	 KC_F3,	  KC_F12,	_______,
  						  _______, _______, _______,          _______, _______, _______,
									_______, _______,          CLEARMODS, WBASE, WBASE
   )
};
