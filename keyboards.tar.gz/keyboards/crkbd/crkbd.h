#pragma once

#ifdef KEYBOARD_crkbd_rev1
  #include "rev1.h"
#endif
