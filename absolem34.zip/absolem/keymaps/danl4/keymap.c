#include QMK_KEYBOARD_H
// LEFT HANDED SPLIT (MINI MANUFORM 4X5)
#include "danl4_common_functions.c"

//make handwired/dactyl_manuform/mini4x5:danl4
//dan@Lithium:~/Documents/QMK/qmk_firmware$
//make handwired/dactyl_manuform/mini4x5:danl4:avrdude

//#define TAPPING_TOGGLE 2 //double tap TT(_XNUMPAD) for toggle, otherwise acts 
//TT(_XNUMPAD)



enum combos {
  QW_BS,
  YI_Ent,//not great for hebrew ון, swap with ER, CV, MComma
  FG_BS,
  DF_Ent,
  JK_BS,
  HJ_Ent,
};

const uint16_t PROGMEM qw_combo[] = {KC_Q, KC_W, COMBO_END};
const uint16_t PROGMEM yi_combo[] = {KC_Y,	KC_I, COMBO_END};
const uint16_t PROGMEM fg_combo[] = {GUILAYER_F, KC_G, COMBO_END};
const uint16_t PROGMEM df_combo[] = {ALT_D,	GUILAYER_F, COMBO_END};
const uint16_t PROGMEM jk_combo[] = {GUI_J,	ALT_K, COMBO_END};
const uint16_t PROGMEM hj_combo[] = {KC_H,GUI_J, COMBO_END};


combo_t key_combos[COMBO_COUNT] = {
  [QW_BS] = COMBO(qw_combo, KC_ENT),
  [YI_Ent] = COMBO(yi_combo, KC_BSPC),
  [FG_BS] = COMBO(fg_combo, KC_BSPC),
  [DF_Ent] = COMBO(df_combo, KC_ENT),
  [JK_BS] = COMBO(jk_combo, KC_BSPC),
  [HJ_Ent] = COMBO(hj_combo, KC_ENT)

};




const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
[_WINBASE] = LAYOUT(  /* Base Layer */
  KC_Q,   KC_W,    KC_E,   KC_R,    KC_T,				KC_Y,	KC_U,    KC_I,     KC_O,     KC_P,\
  SHFT_A, CTRL_S,  ALT_D,  GUILAYER_F,   KC_G,				KC_H,	GUI_J,   ALT_K,    CTRL_L,   SHSQ,\
  MIRR_Z, KC_X,    KC_C,   KC_V,    MIRR_B,				KC_N,	KC_M,    KC_COMM,KC_DOT, SLASHES,\
   NUM_TAB,CTRL_SPC,WIN_ENT, 	ALT_BS,SHFT_SPC,ARROWS\
),


	[_GUILAYER] = LAYOUT(
KC_Q,	KC_W,	KC_E,	KC_R,	KC_T,		KC_Y,KC_U,	KC_I,	KC_O,	KC_P,
S(KC_A),CTRL_S,G(KC_D),G(KC_F),G(KC_G),	KC_H,GUI_J,	ALT_K,	CTRL_L,	SHSQ, 
MIRR_Z,KC_X,	KC_C,	KC_V,	MIRR_B,		KC_N,KC_M,	KC_COMM,KC_DOT,	SLASHES,
                       KC_BSPC,WIN_ENT,	_____,	_____,		KC_BSPC,ARROWS
  ),


[_MIRROR] = LAYOUT(  /*MIRROR and mouse*/
  KC_P,		KC_O,	KC_I,	KC_U,   KC_Y,				KC_MS_ACCEL0, 	KC_MS_BTN1,	KC_MS_UP,  KC_MS_BTN2, 	KC_MS_WH_UP, \
  SHSQ,		CTRL_L,	ALT_K,	GUI_J,  KC_H,				KC_MS_ACCEL1, 	KC_MS_LEFT,	KC_MS_DOWN,KC_MS_RIGHT,	KC_MS_WH_DOWN, \
  SLASHES,	KC_DOT,	KC_COMM,KC_M,	KC_N,				KC_MS_ACCEL2, 	XXXXX,		KC_MS_BTN3,XXXXX,		XXXXX, \
		OSL(_XNUMPAD),	KC_DEL,	KC_BSPC,		LGUI_T(KC_DEL), _____,		_____\

  ),

[_MIRRRB] = LAYOUT(  /*MIRROR reached from B, not freom Z*/
  KC_P,		KC_O,	KC_I,	KC_U,   KC_Y,				KC_MS_ACCEL0, 	KC_MS_BTN1,	KC_MS_UP,  KC_MS_BTN2, 	KC_MS_WH_UP, \
  S(KC_A),		CTRL_L,	ALT_K,	GUI_J,  KC_H,				KC_MS_ACCEL1, 	KC_MS_LEFT,	KC_MS_DOWN,KC_MS_RIGHT,	KC_MS_WH_DOWN, \
  SLASHES,	KC_DOT,	KC_COMM,KC_M,	KC_N,				KC_MS_ACCEL2, 	XXXXX,		KC_MS_BTN3,XXXXX,		XXXXX, \
		OSL(_XARROWS),	KC_DEL,	KC_BSPC,		LGUI_T(KC_DEL), _____,		_____\

  ),

[_XARROWS] = LAYOUT(  // RAISE - Arrows for both hands 
  KC_VOLU,  KC_HOME,   KC_UP,   KC_PGUP,	CURLY, XXXXX,  KC_HOME, KC_UP,   KC_PGUP,  XXXXX,\
  KC_LSFT,  CTRL_LEFT, KC_LEFT, KC_RIGHT,	PARAN, KC_PSCR,  KC_LEFT, KC_DOWN, KC_RIGHT, XXXXX,\
  KC_VOLD,	KC_END,    KC_DOWN, KC_PGDN,	SQUAR, XXXXX,  KC_END,  KC_DOWN, KC_PGDN,  XXXXX, \
  _____,   	_____,	_____, _____,  _____, _____\
),



[_ARROWS] = LAYOUT(  /* RAISE - Arrows for right hand*/
	KC_LALT,	LSFT(KC_LBRACKET),	KC_LBRACKET,KC_LPRN,	KC_RPRN,	        XXXXX,	KC_HOME,KC_UP,	KC_PGUP,	XXXXX,\
	KC_LSHIFT,	KC_LCTRL,			KC_LALT,	KC_LGUI,	KC_APP,	           	KC_PSCR,KC_LEFT,KC_DOWN,KC_RIGHT,	KC_EQUAL,	\
	LCTL(KC_Z),	LCTL(KC_X),			LCTL(KC_C),	LCTL(KC_V),	KC_PSCR,	     	XXXXX,	KC_END,	KC_DOWN,KC_PGDN,	OSL(_NUMPAD),	\
	_____,   	_____,		_____, 				_____,  _____,	_____\
),


[_NUMPAD] = LAYOUT(  /* LOWER - Numpad for right hand, parenthesis and volumne (and cut copy paste) for left*/
	KC_VOLU,  WBASE,	KC_PIPE, 	KC_TILD,	KC_ESC,    		KC_ASTR,KC_7,	KC_8,   KC_9,      KC_0, \
	KC_VOLD,  CURLY,	SQUAR,   	PARAN,		KC_APP,    		KC_SLSH,KC_4,	KC_5,   KC_6,      KC_PLUS, \
	KC_MUTE,  KC_CUT,	KC_COPY, 	KC_PASTE,	KC_PSCR,   		KC_0,	KC_1,	KC_2,   KC_3,      KC_MINS, \
		_____,		_____,		_____,			_____,	KC_KP_DOT,_____ \
),	


[_XNUMPAD] = LAYOUT(  // LOWER - Numpad Left; Symbols Right
	KC_ASTR,KC_7,   KC_8,	KC_9,   KC_0,			KC_BSLS,KC_AMPR, KC_ASTR, KC_LPRN,  KC_0,    \
	KC_SLSH,KC_4,   KC_5,	KC_6,   KC_PLUS,		KC_SLSH,KC_DLR,  KC_PERC, KC_CIRC,  KC_PLUS, \
	KC_0, 	KC_1,   KC_2,	KC_3,	KC_MINS,		KC_0,	KC_EXLM, KC_AT,   KC_HASH,	KC_MINS, \
	_____,	_____,	_____,			_____,_____,KC_KP_DOT \
),


[_FUNC] = LAYOUT(  // ADJUST - Brightness and Media Left; Function Keys Right
	XXXXX,	XXXXX,	KC_BRIU, RESET,	 KC_APP,		KC_WFWD,KC_F7,	KC_F8,	KC_F9, KC_F10, \
	WBASE,  KC_MPRV,KC_MPLY, KC_MNXT,LCTL(KC_LALT),	KC_WBAK,KC_F4,	KC_F5,	KC_F6, KC_F11, \
	KC_CAPS,XXXXX,	KC_BRID, XXXXX,	 KC_PSCR,		XXXXX,	KC_F1,	KC_F2,	KC_F3, KC_F12, \
	_____, _____, 	_____, 			_____,_____,	_____ \
),


[_MOUSE] = LAYOUT(  // Mouse Left; a mess for Right
	KC_TILD,KC_MS_BTN1,	KC_MS_UP,  	KC_MS_BTN2,	KC_MS_WH_UP, 		KC_ESC, XXXXX,	XXXXX,	XXXXX,		XXXXX, \
	WBASE,	KC_MS_LEFT,	KC_MS_DOWN,	KC_MS_RIGHT,KC_MS_WH_DOWN,		XXXXX,	KC_LGUI,KC_LALT,KC_LCTRL,	KC_LSHIFT, \
	XXXXX, 	XXXXX,		KC_MS_BTN3,	XXXXX,		XXXXX,				XXXXX,	XXXXX,	XXXXX,	XXXXX,		XXXXX, \
 	_____, 	KC_SPACE, 	_____, 	_____, _____,_____\
)
};
/*
// Light LEDs 6 to 9 and 12 to 15 red when caps lock is active. Hard to ignore!
const rgblight_segment_t PROGMEM my_capslock_layer[] = RGBLIGHT_LAYER_SEGMENTS(
    {0, 1, HSV_RED}       // Light 4 LEDs, starting with LED 12
);
// Light LEDs 9 & 10 in cyan when keyboard layer 1 is active
const rgblight_segment_t PROGMEM my_layer1_layer[] = RGBLIGHT_LAYER_SEGMENTS(
    {0, 1, HSV_CYAN}
);
// Light LEDs 11 & 12 in purple when keyboard layer 2 is active
const rgblight_segment_t PROGMEM my_layer2_layer[] = RGBLIGHT_LAYER_SEGMENTS(
    {0, 1, HSV_PURPLE}
);
// Light LEDs 13 & 14 in green when keyboard layer 3 is active
const rgblight_segment_t PROGMEM my_layer3_layer[] = RGBLIGHT_LAYER_SEGMENTS(
    {0, 1, HSV_GREEN}
);
// Light LEDs 13 & 14 in green when keyboard layer 3 is active
const rgblight_segment_t PROGMEM my_layer4_layer[] = RGBLIGHT_LAYER_SEGMENTS(
    {0, 1,HSV_PINK}
);


// Now define the array of layers. Later layers take precedence
const rgblight_segment_t* const PROGMEM my_rgb_layers[] = RGBLIGHT_LAYERS_LIST(
    my_capslock_layer,
    my_layer1_layer,    // Overrides caps lock layer
    my_layer2_layer,    // Overrides other layers
    my_layer3_layer,    // Overrides other layers
    my_layer4_layer     // Overrides other layers
);

void keyboard_post_init_user(void) {
    // Enable the LED layers
    rgblight_layers = my_rgb_layers;
};


bool led_update_user(led_t led_state) {
    rgblight_set_layer_state(0, led_state.caps_lock);
    return true;
};

layer_state_t default_layer_state_set_user(layer_state_t state) {
    rgblight_set_layer_state(1, layer_state_cmp(state, _WINBASE));
    return state;
};

//layer_state_t layer_state_set_user(layer_state_t state) {
//    rgblight_set_layer_state(2, layer_state_cmp(state, _XNUMPAD));
//    rgblight_set_layer_state(3, layer_state_cmp(state, _XARROWS));
//    rgblight_set_layer_state(4, layer_state_cmp(state, _NUMPAD));
//    return state;
//};

*/
